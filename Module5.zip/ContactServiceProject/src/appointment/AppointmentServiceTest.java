package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import appointment.Appointment;
import appointment.AppointmentService;
import java.util.Date;

class AppointmentServiceTest {
    private AppointmentService service;
    private Date futureDate;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        futureDate = new Date(System.currentTimeMillis() + 1000000);
    }

    @Test
    void testAddAppointmentSuccess() {
        Appointment appt = new Appointment("A1", futureDate, "Dentist Checkup");
        service.addAppointment(appt);
        assertNotNull(service.getAppointment("A1"));
    }

    @Test
    void testAddDuplicateAppointmentThrowsException() {
        Appointment appt1 = new Appointment("A1", futureDate, "Dentist Checkup");
        Appointment appt2 = new Appointment("A1", futureDate, "Eye Exam");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    @Test
    void testDeleteAppointmentSuccess() {
        Appointment appt = new Appointment("A1", futureDate, "Dentist Checkup");
        service.addAppointment(appt);
        service.deleteAppointment("A1");
        assertNull(service.getAppointment("A1"));
    }

    @Test
    void testDeleteNonExistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("MissingID"));
    }
}