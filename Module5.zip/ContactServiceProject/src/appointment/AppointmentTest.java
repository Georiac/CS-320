package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import appointment.Appointment;
import java.util.Date;

class AppointmentTest {
    private final Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    private final Date pastDate = new Date(System.currentTimeMillis() - 1000000);

    @Test
    void testAppointmentCreationSuccess() {
        Appointment appt = new Appointment("12345", futureDate, "Valid Description");
        assertEquals("12345", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Valid Description", appt.getDescription());
    }

    @Test
    void testAppointmentIdValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Desc"));
    }

    @Test
    void testAppointmentDateValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", pastDate, "Desc"));
    }

    @Test
    void testAppointmentDescriptionValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", futureDate, 
            "This description is way too long and definitely surpasses fifty characters total."));
    }
}