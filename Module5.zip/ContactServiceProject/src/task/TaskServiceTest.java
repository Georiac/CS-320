package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

class TaskServiceTest {
    private TaskService service;
    private final String defaultName = "Jade Bain";
    private final String defaultDesc = "This description is good";

    @BeforeEach
    void setUp() {
        
        service = new TaskService(); 
    }

    @DisplayName("Add a Task")
    @Test
    void testAddUniqueTask() {
        assertEquals(0, service.getTasks().size());
        service.addUniqueTask(defaultName, defaultDesc);
        
        assertTrue(service.getTasks().containsKey("0"));
        assertEquals(defaultName, service.getTasks().get("0").getName());
        assertEquals(defaultDesc, service.getTasks().get("0").getDescription());
    }

    @DisplayName("Delete Task Test")
    @Test
    void testDeleteTask() {
        service.addUniqueTask(defaultName, defaultDesc); // ID "0"
        service.addUniqueTask(defaultName, defaultDesc); // ID "1"
        service.addUniqueTask(defaultName, defaultDesc); // ID "2"
        
        assertEquals(3, service.getTasks().size());
        service.deleteTasks("1");
        assertEquals(2, service.getTasks().size());
        
        
        assertFalse(service.getTasks().containsKey("1")); 
    }

    @DisplayName("Update Task with a good ID Test")
    @Test
    void testUpdateTasks() {
        service.addUniqueTask(defaultName, defaultDesc); // ID "0"
        service.updateTasks("0", defaultName, "New description");
        
        assertEquals("New description", service.getTasks().get("0").getDescription());
        assertEquals(defaultName, service.getTasks().get("0").getName());
    }

    @DisplayName("Test updateTask or Deleting with an invalid ID")
    @Test
    void testBadUpdateAndDeleteTasks() {
        service.addUniqueTask(defaultName, defaultDesc); // ID "0"
        
        // This verifies the application handles missing IDs effectively by throwing errors
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTasks("12345", defaultName, "New description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTasks("12345");
        });
    }
}
