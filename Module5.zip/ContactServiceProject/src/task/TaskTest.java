package task;

import static org.junit.jupiter.api.Assertions.assertEquals; 
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import task.Task;

class TaskTest {

    @DisplayName("Good constructor")
    @Test
    void goodConstructor() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = "This description is good";
        Task tempTask = new Task(id, fullName, description);
        
        assertEquals("1", tempTask.getUniqueID());
        assertEquals(fullName, tempTask.getName());
        assertEquals(description, tempTask.getDescription());
    }

    /**
     * This is a constructor that is invalid with a description that is too long
     */
    @DisplayName("Invalid constructor - Description too long")
    @Test
    void invalidConstructor() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = "This is an invalid description because the text is too longggggggggggg to be an actual string and it should not allow this to work";
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(id, fullName, description);
        });
    }

    /**
     * This is an invalid constructor with long IDs
     */
    @DisplayName("Invalid constructor - Long ID")
    @Test
    void invalidIDConstruct() {
        String id = "1234567891011121314151617";
        String fullName = "Jade Bain";
        String description = "description";
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(id, fullName, description);
        });
    }

    /**
     * This is an invalid constructor with null IDs
     */
    @DisplayName("Invalid constructor - Null ID")
    @Test
    void invalidNullConstruct() {
        String id = null;
        String fullName = "Jade Bain";
        String description = "description";
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(id, fullName, description);
        });
    }

    /**
     * This will test the setFullName with a good input
     */
    @DisplayName("Test a valid setName")
    @Test
    public void testGoodName() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = "This description is good";
        Task tempTask = new Task(id, fullName, description);
        
        tempTask.setName("Name test");
        assertEquals("Name test", tempTask.getName());
    }

    /**
     * This will test the setFullName with a null input
     */
    @DisplayName("Tests invalid null setName")
    @Test
    public void testNullName() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = "This description is good";
        Task tempTask = new Task(id, fullName, description);
        
        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName(null);
        });
    }

    /**
     * This will test the setFullName that has a long input
     */
    @DisplayName("Test invalid long setName")
    @Test
    public void testLongName() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = "This description is good";
        Task tempTask = new Task(id, fullName, description);
        
        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName("This name is incredibly long and why is this a name, anyway");
        });
    }

    /**
     * This will test the setFullName with an empty string
     */
    @DisplayName("Test an invalid empty setName")
    @Test
    public void testEmptyName() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = "This description is good";
        Task tempTask = new Task(id, fullName, description);
        
        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName("");
        });
    }

    /**
     * This will test the setDescription with an empty string
     */
    @DisplayName("Test an invalid empty description")
    @Test
    public void testEmptyDescription() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = "";
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(id, fullName, description);
        });
    }

    /**
     * This will test the setDescription with a null string
     */
    @DisplayName("Test an invalid null description")
    @Test
    public void testNullDescription() {
        String id = "1";
        String fullName = "Jade Bain";
        String description = null;
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(id, fullName, description);
        });
    }
}
