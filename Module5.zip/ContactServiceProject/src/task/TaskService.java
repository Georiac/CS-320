package task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private int currentIDNum = 0; 
    private final Map<String, Task> tasks = new HashMap<>();

    public void addUniqueTask(String name, String description) {
        String stringID = Integer.toString(currentIDNum);
        Task tempTask = new Task(stringID, name, description);
        tasks.put(stringID, tempTask);
        ++currentIDNum;
    }

    public void deleteTasks(String id) {
        if (tasks.containsKey(id)) {
            tasks.remove(id);
        } else {
            throw new IllegalArgumentException("Task ID does not exist.");
        }
    }

    public void updateTasks(String id, String newName, String newDescription) {
        if (tasks.containsKey(id)) {
            tasks.get(id).setName(newName);
            tasks.get(id).setDescription(newDescription);
        } else {
            throw new IllegalArgumentException("Task ID does not exist.");
        }
    }

    public Map<String, Task> getTasks() {
        return tasks;
    }
}
